local function pre_process(msg) 
  local jalal = msg['id']
  local user = msg.from.id
  local chat = msg.to.id
  local hash = 'mate:'..chat..':'..user
  if msg.fwd_from and not is_momod(msg) then
    if redis:get(hash) and msg.fwd_from and not is_momod(msg) then 
      delete_msg(msg.id, ok_cb, false) 
      redis:del(hash) 
      kick_user(user, chat)
    else
      local q = "عزيزي~["..msg.from.first_name.."]".."\n".."تنبية : لا تقم ب اعادة توجيه في هاذة المجموعة.❗️ هاذا تحذير في المرة القادمة سوف اطردك من المجموعة ⛔️".."\n".."#username: @"..(msg.from.username or " ")
      reply_msg(jalal, q, ok_cb, true) 
      redis:set(hash, true)
    end
  end
  return  msg
end
       

local function run(msg, matches) 
  local jalal = msg['id'] 
  if matches[1] == 'تحذير توجيه' then
    if is_momod(msg) then 
      local hash = 'mate:'..msg.to.id 
      redis:set(hash, true) 
      local x = ' تم تفعيل خاصية منع اعادة توجيه #بلتحذير. ❗️⛔️'
      reply_msg(jalal, x, ok_cb, true) 
    else 
      local asdy = 'هاذ الامر للمشرفين #فقط❗️⛔️' 
      reply_msg(jalal, asdy, ok_cb, true) 
    end
  end
  if matches[1] == 'ايقاف التحذير' then
    if is_momod(msg) then 
      local hash = 'mate:'..msg.to.id 
      redis:del(hash) 
      local don = ' تم الغاء تفعيل خاصية منع اعادة توجيه #بلتحذير. ❗️⛔️' 
      reply_msg(jalal, don, ok_cb, true) 
    else
      local jalal_aldon = 'هاذ الامر للمشرفين #فقط❗️⛔️' 
      reply_msg(jalal, jalal_aldon, ok_cb, true) 
    end 
  end 
end
return { 
    patterns = {
"^(تحذير توجيه)$",
"^(ايقاف التحذير)$"
 
    }, 
     
run = run, 
    pre_process = pre_process 
}
-- -- arabic : @O_o_king