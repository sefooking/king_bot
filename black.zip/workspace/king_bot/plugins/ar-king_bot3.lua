do

function run(msg, matches)
return [[

االبوت الذي يعمل على مجوعات السوبر 🔸

يعمل البوت على مجموعات سوبر تصل الى5k عضو 🔷

     ≪تم صنع البوت بواسطة المطور≫
                      『  sefoo alobidi 』
                      
                      🔶DEV :🔶DEV : OS @O_o_king
                      
                      👇🏿تأبعـونأَ كل جَديد عل قنأةَ السورس👇🏿
                      
                      [ @freedom1234 ]
                      
                     👇🏿للأستفسار:- راسل المطور:- ☢⚜ 🔶 @O_o_king
                     
                     🔶 SUPPORT :- @O_o_1bot
                      
]]
end

return {
description = "Shows bot q", 
usage = "spam Shows bot q",
patterns = {
"^(dev)$",
},
run = run 
}
end
-- arabic : @O_o_king