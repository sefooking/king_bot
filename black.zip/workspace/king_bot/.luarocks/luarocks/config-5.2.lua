rocks_trees = {
   { name = [[system]], root = [[/home/ubuntu/workspace/TH3_BOSS/.luarocks]] }
}
